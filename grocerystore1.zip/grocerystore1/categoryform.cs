﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Collections;

namespace grocerystore1
{
    public partial class categoryform : Form
    {
        public categoryform()
        {
            InitializeComponent();
        }
        public static SqlConnection cn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\login.mdf; Integrated Security = True");
        SqlDataAdapter da;
        DataTable dt;
         
        private void btnadd_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "" || txtname.Text == "" || txtdescri.Text == "")
            {
                MessageBox.Show("Please Fill Details", "GSMS", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                try
                {
                    cn.Open();
                    string query = "insert into categorytable values (" + txtid.Text + ",'" + txtname.Text + "', '" + txtdescri.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, cn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Category Added Successfully...");
                    cn.Close();
                    txtid.Text = "";
                    txtname.Text = "";
                    txtdescri.Text = "";
                    showdata();
                }
                catch (Exception)
                {
                    MessageBox.Show("Please Enter Differnt Id", "GSMS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

        }
        public void showdata()
        {
            da = new SqlDataAdapter("select * from categorytable", cn);
            dt = new DataTable();
            da.Fill(dt);
            dgvcategories.DataSource = dt;
            cn.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            lblDate.Text = DateTime.Today.Day.ToString() + "/" + DateTime.Today.Month.ToString() + "/" + DateTime.Today.Year.ToString();
        }
        private void categoryform_Load(object sender, EventArgs e)
        {
            showdata();
            lblSellerName.Text = register.SellerName;
        }

        private void close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void gunaGradientButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "" || txtname.Text == "" || txtdescri.Text == "")
            {
                MessageBox.Show("Please Fill Details", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                cn.Open();
                string query = "delete from categorytable where id =" + txtid.Text + "";
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Category Deleted Successfully...");
                showdata();
            }    
        }

        private void btnproduct_Click(object sender, EventArgs e)
        {
            this.Hide();
            Productform pf = new Productform();
            pf.Show();
        }

        private void btncategory_Click(object sender, EventArgs e)
        {

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "" || txtname.Text == "" || txtdescri.Text == "")
            {
                MessageBox.Show("Please Fill Details", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                cn.Open();
                SqlCommand sqlCommand = new SqlCommand("update categorytable set name = '" + txtname.Text + "', description = '" + txtdescri.Text + "' where id = '" + int.Parse(txtid.Text) + "' ", cn);
                sqlCommand.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Category Updated...");
                showdata();
            }
        }

        private void btnseller_Click(object sender, EventArgs e)
        {
            this.Hide();
            sellerform sf = new sellerform();
            sf.Show();
        }

        private void btnselling_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            sellingform sef = new sellingform();
            sef.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
           
        }

        private void btnsignup_Click(object sender, EventArgs e)
        {
            this.Hide();
            register r = new register();
            r.Show();
        }

        private void dgvcategories_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            string sq = "select * from categorytable values (" + txtid.Text + ",'" + txtname.Text + "', '" + txtdescri.Text + "')";
            SqlCommand cmd = new SqlCommand(sq, cn);
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvcategories.Rows[e.RowIndex];
                txtid.Text = row.Cells["id"].Value.ToString();
                txtname.Text = row.Cells["name"].Value.ToString();
                txtdescri.Text = row.Cells["description"].Value.ToString();
            }
        }

        private void btnreload_Click(object sender, EventArgs e)
        {
            showdata();
            txtid.Text = "";
            txtname.Text = "";
            txtdescri.Text = "";
        }
    }
}
