﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grocerystore1
{
    public partial class loading : Form
    {
        public loading()
        {
            InitializeComponent();
        }        
        int startpoint = 0;
       
        private void loading_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            startpoint += 1;
            ProgressBar1.Value = startpoint;
            if (ProgressBar1.Value == 25)
            {
                ProgressBar1.Value = 0;
                timer1.Stop();
                this.Hide();
                register r = new register();
                r.Show();
            }
        }
    }
}
