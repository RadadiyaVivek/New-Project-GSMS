﻿namespace grocerystore1
{
    partial class register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(register));
            this.txtpwd = new System.Windows.Forms.TextBox();
            this.txtunm = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.close = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnadmin = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnsellerlogin = new Bunifu.Framework.UI.BunifuThinButton2();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtpwd
            // 
            this.txtpwd.BackColor = System.Drawing.Color.White;
            this.txtpwd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpwd.Location = new System.Drawing.Point(412, 255);
            this.txtpwd.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtpwd.Name = "txtpwd";
            this.txtpwd.PasswordChar = '●';
            this.txtpwd.Size = new System.Drawing.Size(241, 29);
            this.txtpwd.TabIndex = 4;
            // 
            // txtunm
            // 
            this.txtunm.BackColor = System.Drawing.Color.White;
            this.txtunm.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtunm.Location = new System.Drawing.Point(412, 210);
            this.txtunm.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtunm.Name = "txtunm";
            this.txtunm.Size = new System.Drawing.Size(241, 29);
            this.txtunm.TabIndex = 3;
            this.txtunm.TextChanged += new System.EventHandler(this.txtunm_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(175, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(389, 28);
            this.label3.TabIndex = 3;
            this.label3.Text = "Grocery Store Management System";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.close);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(732, 41);
            this.panel1.TabIndex = 12;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.InitialImage")));
            this.pictureBox3.Location = new System.Drawing.Point(8, 7);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(26, 26);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // close
            // 
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.Image = global::grocerystore1.Properties.Resources.close;
            this.close.InitialImage = ((System.Drawing.Image)(resources.GetObject("close.InitialImage")));
            this.close.Location = new System.Drawing.Point(696, 3);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(31, 31);
            this.close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.close.TabIndex = 6;
            this.close.TabStop = false;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(33, 149);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(189, 168);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // btnadmin
            // 
            this.btnadmin.ActiveBorderThickness = 1;
            this.btnadmin.ActiveCornerRadius = 20;
            this.btnadmin.ActiveFillColor = System.Drawing.Color.Transparent;
            this.btnadmin.ActiveForecolor = System.Drawing.Color.Maroon;
            this.btnadmin.ActiveLineColor = System.Drawing.SystemColors.Control;
            this.btnadmin.BackColor = System.Drawing.SystemColors.Control;
            this.btnadmin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnadmin.BackgroundImage")));
            this.btnadmin.ButtonText = "Admin";
            this.btnadmin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnadmin.Font = new System.Drawing.Font("Constantia", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadmin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnadmin.IdleBorderThickness = 1;
            this.btnadmin.IdleCornerRadius = 20;
            this.btnadmin.IdleFillColor = System.Drawing.Color.Transparent;
            this.btnadmin.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnadmin.IdleLineColor = System.Drawing.Color.Transparent;
            this.btnadmin.Location = new System.Drawing.Point(597, 291);
            this.btnadmin.Margin = new System.Windows.Forms.Padding(5);
            this.btnadmin.Name = "btnadmin";
            this.btnadmin.Size = new System.Drawing.Size(53, 39);
            this.btnadmin.TabIndex = 6;
            this.btnadmin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnadmin.Click += new System.EventHandler(this.btnadmin_Click);
            // 
            // btnsellerlogin
            // 
            this.btnsellerlogin.ActiveBorderThickness = 1;
            this.btnsellerlogin.ActiveCornerRadius = 10;
            this.btnsellerlogin.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnsellerlogin.ActiveForecolor = System.Drawing.Color.Black;
            this.btnsellerlogin.ActiveLineColor = System.Drawing.Color.Black;
            this.btnsellerlogin.BackColor = System.Drawing.SystemColors.Control;
            this.btnsellerlogin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnsellerlogin.BackgroundImage")));
            this.btnsellerlogin.ButtonText = " Login";
            this.btnsellerlogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsellerlogin.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsellerlogin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnsellerlogin.IdleBorderThickness = 1;
            this.btnsellerlogin.IdleCornerRadius = 10;
            this.btnsellerlogin.IdleFillColor = System.Drawing.Color.White;
            this.btnsellerlogin.IdleForecolor = System.Drawing.Color.IndianRed;
            this.btnsellerlogin.IdleLineColor = System.Drawing.Color.Black;
            this.btnsellerlogin.Location = new System.Drawing.Point(562, 331);
            this.btnsellerlogin.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnsellerlogin.Name = "btnsellerlogin";
            this.btnsellerlogin.Size = new System.Drawing.Size(91, 42);
            this.btnsellerlogin.TabIndex = 5;
            this.btnsellerlogin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnsellerlogin.Click += new System.EventHandler(this.btnsellerlogin_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Mistral", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(401, 129);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 38);
            this.label7.TabIndex = 9;
            this.label7.Text = "Seller Login";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gainsboro;
            this.panel2.ForeColor = System.Drawing.Color.Transparent;
            this.panel2.Location = new System.Drawing.Point(287, 151);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(370, 1);
            this.panel2.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(283, 258);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 24);
            this.label2.TabIndex = 19;
            this.label2.Text = "Password : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(283, 213);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 24);
            this.label1.TabIndex = 20;
            this.label1.Text = "Username : ";
            // 
            // register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(731, 471);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnsellerlogin);
            this.Controls.Add(this.btnadmin);
            this.Controls.Add(this.txtpwd);
            this.Controls.Add(this.txtunm);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "register";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "register";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtpwd;
        private System.Windows.Forms.TextBox txtunm;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox close;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnadmin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnsellerlogin;
    }
}