﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace grocerystore1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static string SellerName = "" ;
       
        private void close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Enter Username & Password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (textBox1.Text == "admin" && textBox2.Text == "password")
            {
                this.Hide();
                Productform pf = new Productform();
                pf.Show();
            }
        }

        private void btnseller_Click(object sender, EventArgs e)
        {
            this.Hide();
            register rg = new register();
            rg.Show();
        }
    }
}
