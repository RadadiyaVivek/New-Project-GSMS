﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace grocerystore1
{
    public partial class register : Form
    {
        public register()
        {
            InitializeComponent();
        }
        public static string SellerName= "";
        
        public static SqlConnection cn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\login.mdf; Integrated Security = True");

        private void close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnadmin_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void btnsellerlogin_Click(object sender, EventArgs e)
        {
            if (txtunm.Text == "" || txtpwd.Text == "")
            {
                MessageBox.Show("Enter Username & Password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                string sql = "select * from SellersTbl where SellerName='" + txtunm.Text + "' and SellerPassword='" + txtpwd.Text + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql, cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 1)
                {
                    this.Hide();
                    Productform pf = new Productform();
                    pf.Show();
                }
                else
                {
                    MessageBox.Show("Enter Valid Information", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void txtunm_TextChanged(object sender, EventArgs e)
        {
           SellerName = txtunm.Text;
        }
    }
}
