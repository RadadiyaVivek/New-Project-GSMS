﻿namespace grocerystore1
{
    partial class loading
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(loading));
            this.loadingimage = new System.Windows.Forms.PictureBox();
            this.name = new System.Windows.Forms.Label();
            this.ProgressBar1 = new Bunifu.Framework.UI.BunifuProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.labelloading = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.loadingimage)).BeginInit();
            this.SuspendLayout();
            // 
            // loadingimage
            // 
            this.loadingimage.Image = ((System.Drawing.Image)(resources.GetObject("loadingimage.Image")));
            this.loadingimage.Location = new System.Drawing.Point(238, 106);
            this.loadingimage.Name = "loadingimage";
            this.loadingimage.Size = new System.Drawing.Size(277, 204);
            this.loadingimage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.loadingimage.TabIndex = 18;
            this.loadingimage.TabStop = false;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Leelawadee UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.name.Location = new System.Drawing.Point(288, 452);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(176, 15);
            this.name.TabIndex = 3;
            this.name.Text = "POWERED BY VR TECHNOLOGY";
            // 
            // ProgressBar1
            // 
            this.ProgressBar1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ProgressBar1.BorderRadius = 1;
            this.ProgressBar1.Location = new System.Drawing.Point(157, 352);
            this.ProgressBar1.MaximumValue = 25;
            this.ProgressBar1.Name = "ProgressBar1";
            this.ProgressBar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ProgressBar1.Size = new System.Drawing.Size(436, 10);
            this.ProgressBar1.TabIndex = 19;
            this.ProgressBar1.Value = 0;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // labelloading
            // 
            this.labelloading.AutoSize = true;
            this.labelloading.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelloading.ForeColor = System.Drawing.Color.Black;
            this.labelloading.Location = new System.Drawing.Point(244, 397);
            this.labelloading.Name = "labelloading";
            this.labelloading.Size = new System.Drawing.Size(295, 25);
            this.labelloading.TabIndex = 3;
            this.labelloading.Text = "Loading Application.... Please Wait !";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(732, 41);
            this.panel1.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(174, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(389, 28);
            this.label4.TabIndex = 21;
            this.label4.Text = "Grocery Store Management System";
            // 
            // loading
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(731, 471);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ProgressBar1);
            this.Controls.Add(this.name);
            this.Controls.Add(this.labelloading);
            this.Controls.Add(this.loadingimage);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "loading";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "loading";
            this.TransparencyKey = System.Drawing.Color.WhiteSmoke;
            this.Load += new System.EventHandler(this.loading_Load);
            ((System.ComponentModel.ISupportInitialize)(this.loadingimage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox loadingimage;
        private System.Windows.Forms.Label name;
        private Bunifu.Framework.UI.BunifuProgressBar ProgressBar1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label labelloading;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
    }
}