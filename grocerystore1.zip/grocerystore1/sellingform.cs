﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Collections;
using System.Data.SqlTypes;

namespace grocerystore1
{
    public partial class sellingform : Form
    {
        public sellingform()
        {
            InitializeComponent();
        }

        string SellerName;
        int grdtotal = 0;

        public static SqlConnection cn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\login.mdf; Integrated Security = True");
        
        private void showdata()
        {
            cn.Open();
            string query = "select ProdName , ProdPrice from ProductsTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, cn);
            SqlCommandBuilder scb = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            dgvproducts.DataSource = ds.Tables[0];
            cn.Close();
        }
        private void showdatabills()
        {
            cn.Open();
            string query = "select * from BillsTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, cn);
            SqlCommandBuilder scb = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            dgvbills.DataSource = ds.Tables[0];
            cn.Close();
        }
        private void FillCategory()
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand("select name from categorytable", cn);
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("name", typeof(string));
            dt.Load(rdr);
            cn.Close();

        }
        private void btnproduct_Click(object sender, EventArgs e)
        {
            this.Hide();
            Productform pf = new Productform();
            pf.Show();
        }

        private void btncategory_Click(object sender, EventArgs e)
        {
            this.Hide();
            categoryform cf = new categoryform();
            cf.Show();
        }

        private void btnseller_Click(object sender, EventArgs e)
        {
            this.Hide();
            sellerform sf = new sellerform();
            sf.Show();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void sellingform_Load(object sender, EventArgs e)
        {
            showdata();
            showdatabills();
            FillCategory();
            lblSellerName.Text = register.SellerName;
            lblAmount.Text = "" + grdtotal;
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (txtbillid.Text == "")
            {
                MessageBox.Show("Missing Bill Id");
            }
            else
            {
                try
                {
                    cn.Open();
                    string query = "insert into BillsTbl values ('" + txtbillid.Text + "','" + lblSellerName.Text + "', '" + lblDate.Text + "','" + txtcustomer.Text + "','" + lblAmount.Text+"')";
                    SqlCommand cmd = new SqlCommand(query, cn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Order Added Successfully...");
                    cn.Close();
                    showdatabills();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    cn.Close();
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            lblDate.Text = DateTime.Today.Day.ToString() + "/" + DateTime.Today.Month.ToString() + "/" +DateTime.Today.Year.ToString();
            SellerName = lblSellerName.Text;
        }

        private void PrintDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            Font font = new Font("Corbel", 20);
            Brush brush = Brushes.Blue;
            float x = e.MarginBounds.Left;
            float y = e.MarginBounds.Top;

            e.Graphics.DrawString("KE Mart ", new Font("Corbel", 25, FontStyle.Bold), Brushes.Black, new Point(305,20));
            e.Graphics.DrawString("Bill ID :     " + dgvbills.SelectedRows[0].Cells[0].Value.ToString(), new Font("Century Gothic", 20, FontStyle.Bold), Brushes.Blue, new Point(100, 100));
            e.Graphics.DrawString("Sold By :     " + dgvbills.SelectedRows[0].Cells[1].Value.ToString(), new Font("Century Gothic", 20, FontStyle.Bold), Brushes.Blue, new Point(100, 140));
            e.Graphics.DrawString("Date    :     " + dgvbills.SelectedRows[0].Cells[2].Value.ToString(), new Font("Century Gothic", 20, FontStyle.Bold), Brushes.Blue, new Point(100, 180));
            e.Graphics.DrawString("Customer Name :  " + dgvbills.SelectedRows[0].Cells[3].Value.ToString(), new Font("Century Gothic", 20, FontStyle.Bold), Brushes.Blue, new Point(100, 220));
            e.Graphics.DrawString("Total Amount :   " + dgvbills.SelectedRows[0].Cells[4].Value.ToString(), new Font("Century Gothic", 20, FontStyle.Bold), Brushes.Red, new Point(100, 270));
            e.Graphics.DrawString("Thank You for being Best Customer of our store...!", new Font("Corbel", 15, FontStyle.Bold), Brushes.LightGray, new Point(203, 370));
            e.Graphics.DrawString("VR TECHNOLOGY", new Font("Corbel", 15, FontStyle.Bold), Brushes.Black, new Point(350, 1070));
            
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            showdata();
            txtbillid.Text = "";
            txtcustomer.Text = "";
            txtname.Text = "";
            txtprice.Text = "";
            prodtotalrs.Text = "";
            lblAmount.Text = "" + grdtotal;
        }
       
        private void btnaddproduct_Click(object sender, EventArgs e)
        {
            if (txtname.Text == "" || txtquantity.Text == "")
            {
                MessageBox.Show("Please Fill Details", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                cn.Open();
                string qry = "INSERT INTO orderstbl VALUES ('" + txtbillid.Text + "', '" + txtname.Text + "', '" + txtquantity.Text + "', '" + txtprice.Text + "', '" + prodtotalrs.Text + "')";
                SqlCommand cmd = new SqlCommand(qry, cn);
                cmd.ExecuteNonQuery(); 
                MessageBox.Show("Data Added Sussccesfully !");
                cn.Close();
                deleteorder();
                showdata();
                showdatabills();
                FillCategory();
                int tot = Convert.ToInt32(txtquantity.Text) * Convert.ToInt32(txtprice.Text);
                grdtotal = grdtotal + tot;
                lblAmount.Text = ""+grdtotal;
            }
        }
        private void txtquantity_ValueChanged(object sender, EventArgs e)
        {
            if (txtquantity.Text == "" || txtprice.Text == "")
            {
                MessageBox.Show("Please Fill Details", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                Int64 quan = Convert.ToInt64(txtquantity.Value);
                Int64 prc = Convert.ToInt64(txtprice.Text);
                prodtotalrs.Text = (quan * prc).ToString();
            }
        }
        public void deleteorder()
        {
            cn.Open();
            SqlCommand sqlCommand = new SqlCommand("delete orderstbl ", cn);
            sqlCommand.ExecuteNonQuery();
            //MessageBox.Show("Deleted Successfully...");
            cn.Close();
        }
        private void btndelete_Click(object sender, EventArgs e)
        {
            cn.Open();
            SqlCommand sqlCommand = new SqlCommand("delete BillsTbl where BillId = '" + txtbillid.Text+ "' ", cn);
            sqlCommand.ExecuteNonQuery();
            MessageBox.Show("Deleted Successfully...");
            cn.Close();
            showdatabills();
            showdata();
            txtbillid.Text = "";
            txtcustomer.Text = "";
            txtname.Text = "";
            txtprice.Text = "";
            prodtotalrs.Text = "";
        }

        private void dgvproducts_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            txtname.Text = dgvproducts.SelectedRows[0].Cells[0].Value.ToString();
            txtprice.Text = dgvproducts.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void dgvbills_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            string sq = "select * from BillsTbl values (" + txtbillid.Text + ")";
            SqlCommand cmd = new SqlCommand(sq, cn);
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvbills.Rows[e.RowIndex];
                txtbillid.Text = row.Cells["BillId"].Value.ToString();
            }
        }

        private void btnprint_Click_1(object sender, EventArgs e)
        {
            if (PrintPreviewDialog.ShowDialog() == DialogResult.OK)
            {
                PrintDocument.Print();
            }
        }
    }
}
