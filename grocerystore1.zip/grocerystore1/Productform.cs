﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace grocerystore1
{
    public partial class Productform : Form
    {
        public Productform()
        {
            InitializeComponent();
        }
        public static SqlConnection cn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\login.mdf; Integrated Security = True");
        SqlDataAdapter da;
        DataTable dt;

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            lblDate.Text = DateTime.Today.Day.ToString() + "/" + DateTime.Today.Month.ToString() + "/" + DateTime.Today.Year.ToString();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Productform_Load(object sender, EventArgs e)
        {
            FillCategory();
            showdata();
            lblSellerName.Text = register.SellerName;
        }

        private void btncategory_Click(object sender, EventArgs e)
        {
            this.Hide();
            categoryform cf = new categoryform();
            cf.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            sellerform sf = new sellerform();
            sf.Show();
        }

        private void btnselling_Click(object sender, EventArgs e)
        {
            this.Hide();
            sellingform sf = new sellingform();
            sf.Show();
        }
        public void showdata()
        {
            da = new SqlDataAdapter("select * from ProductsTbl", cn);
            dt = new DataTable();
            da.Fill(dt);
            dgvproducts.DataSource = dt;
            cn.Close();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "" || txtname.Text == "" || txtquantity.Text == "" || txtprice.Text == "")
            {
                MessageBox.Show("Please Enter Product Details", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                try
                {
                    cn.Open();
                    string query = "insert into ProductsTbl values (" + txtid.Text + ",'" + txtname.Text + "','" + txtquantity.Text + "', '" + txtprice.Text + "','" + txtcategory.SelectedValue.ToString() + "')";
                    SqlCommand cmd = new SqlCommand(query, cn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Product Added Successfully...");
                    cn.Close();
                    txtid.Text = "";
                    txtname.Text = "";
                    txtquantity.Text = "";
                    txtprice.Text = "";
                    txtcategory.Text = "";
                    showdata();
                }
                catch (Exception)
                {
                    MessageBox.Show("Please Enter Differnt Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtid.Text = "";
                    txtname.Text = "";
                    txtquantity.Text = "";
                    txtprice.Text = "";
                    txtcategory.Text = "";
                }
            }
        }
        private void FillCategory()
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand("select name from categorytable", cn);
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("name", typeof(string));
            dt.Load(reader);
            txtcategory.ValueMember = "name";
            txtcategory.DataSource = dt;
            searchcombo.ValueMember = "name";
            searchcombo.DataSource = dt;
            cn.Close();
        }


        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "" || txtname.Text == "" || txtquantity.Text == "" || txtprice.Text == "")
            {
                MessageBox.Show("Please Fill Details", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                cn.Open();
                string query = "update ProductsTbl set ProdName = '" + txtname.Text + "', ProdQty = '" + txtquantity.Text + "',ProdPrice= '" + txtprice.Text + "',ProdCat = '" + txtcategory.SelectedValue + "'  where ProdId = '" + int.Parse(txtid.Text) + "' ";
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product Updated...");
                cn.Close();
                showdata();
                txtid.Text = "";
                txtname.Text = "";
                txtquantity.Text = "";
                txtprice.Text = "";
                txtcategory.Text = "";
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "" || txtname.Text == "" || txtquantity.Text == "" || txtprice.Text == "")
            {
                MessageBox.Show("Please Fill Details", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                cn.Open();
                SqlCommand sqlCommand = new SqlCommand("delete ProductsTbl where ProdId = '" + int.Parse(txtid.Text) + "' ", cn);
                sqlCommand.ExecuteNonQuery();
                MessageBox.Show("Product Deleted Successfully...");
                cn.Close();
                showdata();
                txtid.Text = "";
                txtname.Text = "";
                txtquantity.Text = "";
                txtprice.Text = "";
            }

        }

        private void searchcombo_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cn.Open();
            string q = "select * from ProductsTbl where ProdCat = '" + searchcombo.SelectedValue.ToString() + "' ";
            SqlDataAdapter sda = new SqlDataAdapter(q, cn);
            SqlCommandBuilder Builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            dgvproducts.DataSource = ds.Tables[0];
            cn.Close();
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            showdata();
            txtid.Text = "";
            txtname.Text = "";
            txtquantity.Text = "";
            txtprice.Text = "";
        }
        private void dgvproducts_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            string sq = "select * from categorytable values (" + txtid.Text + ",'" + txtname.Text + "', '" + txtquantity.Text + "','" + txtprice.Text + "', '" + txtcategory.Text + "')";
            SqlCommand cmd = new SqlCommand(sq, cn);

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvproducts.Rows[e.RowIndex];
                txtid.Text = row.Cells["ProdId"].Value.ToString();
                txtname.Text = row.Cells["ProdName"].Value.ToString();
                txtquantity.Text = row.Cells["ProdQty"].Value.ToString();
                txtprice.Text = row.Cells["ProdPrice"].Value.ToString();
                txtcategory.Text = row.Cells["ProdCat"].Value.ToString();
            }
        }
    }
}
