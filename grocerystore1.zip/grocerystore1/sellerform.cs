﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace grocerystore1
{
    public partial class sellerform : Form
    {
        public sellerform()
        {
            InitializeComponent();
        }
        public static SqlConnection cn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\login.mdf; Integrated Security = True");
        SqlDataAdapter da;
        DataTable dt;

        public void showdata()
        {
            cn.Open();
            da = new SqlDataAdapter("select * from SellersTbl", cn);
            dt = new DataTable();
            da.Fill(dt);
            dgvsellers.DataSource = dt;
            cn.Close();
        }
        private void sellerform_Load(object sender, EventArgs e)
        {
            showdata();
            lblSellerName.Text = register.SellerName;
        }

        private void btnproduct_Click(object sender, EventArgs e)
        {
            this.Hide();
            Productform pf = new Productform();
            pf.Show();
        }

        private void btncategory_Click(object sender, EventArgs e)
        {
            this.Hide();
            categoryform cf = new categoryform();
            cf.Show();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnselling_Click(object sender, EventArgs e)
        {
            this.Hide();
            sellingform sef = new sellingform();
            sef.Show();
        }
        
        private void btnadd_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "" || txtname.Text == "" || txtage.Text == "" || txtmobileno.Text == "" || txtpwd.Text == "")
            {
                MessageBox.Show("Please Enter Seller Details", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                try
                {
                    cn.Open();
                    string query = "insert into SellersTbl values (" + txtid.Text + ",'" + txtname.Text + "','" + txtage.Text + "', '" + txtmobileno.Text + "','" + txtpwd.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, cn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Seller Added Successfully...");
                    cn.Close();
                    txtid.Text = "";
                    txtname.Text = "";
                    txtage.Text = "";
                    txtmobileno.Text = "";
                    txtpwd.Text = "";
                    showdata();
                }
                catch (Exception)
                {
                    MessageBox.Show("Please Enter Differnt Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtid.Text = "";
                    txtname.Text = "";
                    txtage.Text = "";
                    txtmobileno.Text = "";
                    txtpwd.Text = "";
                }
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "" || txtname.Text == "" || txtage.Text == "" || txtmobileno.Text == "" || txtpwd.Text == "")
            {
                MessageBox.Show("Please Enter Seller Details", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            { 
                cn.Open();
                string query = "update SellersTbl set SellerName = '" + txtname.Text + "', SellerAge = '" + txtage.Text + "',SellerMobileNo = '" + txtmobileno.Text + "', SellerPassword = '" + txtpwd.Text + "' where SellerId = '" + int.Parse(txtid.Text) + "' ";
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated...");
                cn.Close();
                showdata();
                txtid.Text = "";
                txtname.Text = "";
                txtage.Text = "";
                txtmobileno.Text = "";
                txtpwd.Text = "";
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "" || txtname.Text == "" || txtage.Text == "" || txtmobileno.Text == "" || txtpwd.Text == "")
            {
                MessageBox.Show("Please Enter Seller Details", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                cn.Open();
                SqlCommand sqlCommand = new SqlCommand("delete SellersTbl where SellerId = '" + int.Parse(txtid.Text) + "' ", cn);
                sqlCommand.ExecuteNonQuery();
                MessageBox.Show("Seller Deleted Successfully...");
                cn.Close();
                showdata();
                txtid.Text = "";
                txtname.Text = "";
                txtage.Text = "";
                txtmobileno.Text = "";
                txtpwd.Text = "";
            }
        }

       
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            lblDate.Text = DateTime.Today.Day.ToString() + "/" + DateTime.Today.Month.ToString() + "/" + DateTime.Today.Year.ToString();
        }
        private void btnreset_Click(object sender, EventArgs e)
        {
            showdata();
            txtid.Text = "";
            txtname.Text = "";
            txtage.Text = "";
            txtmobileno.Text = "";
            txtpwd.Text = "";
        }

        private void dgvsellers_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            string sq = "select * from SellersTbl values (" + txtid.Text + ",'" + txtname.Text + "','" + txtage.Text + "', '" + txtmobileno.Text + "','" + txtpwd.Text + "')";
            SqlCommand cmd = new SqlCommand(sq, cn);

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvsellers.Rows[e.RowIndex];
                txtid.Text = row.Cells["SellerId"].Value.ToString();
                txtname.Text = row.Cells["SellerName"].Value.ToString();
                txtage.Text = row.Cells["SellerAge"].Value.ToString();
                txtmobileno.Text = row.Cells["SellerMobileNo"].Value.ToString();
                txtpwd.Text = row.Cells["SellerPassword"].Value.ToString();

            }
        }
    }
}
